#!/usr/bin/env bash
# ============================================================================
# Local verification harness for the HABBA schema.
# Requires a running PostgreSQL (no Supabase needed): migrations + RLS tests
# run against a throw-away database, with Supabase's auth.uid() stubbed.
#
#   ./run_tests.sh            # uses psql as the current OS user mapping to postgres
# ============================================================================
set -euo pipefail
cd "$(dirname "$0")"

DB="${DB:-habba_test}"
PSQL_SUPER="${PSQL_SUPER:-sudo -u postgres psql}"

echo "→ recreating $DB"
$PSQL_SUPER -q -c "drop database if exists $DB" -c "create database $DB"

echo "→ stubbing Supabase auth for local runs"
$PSQL_SUPER -q -d "$DB" -f tests/00_local_supabase_stub.sql

for f in migrations/0001_schema.sql migrations/0002_rls.sql migrations/0003_functions.sql \
         migrations/0006_seed_demo.sql migrations/0005_security_hardening.sql; do
  printf "  applying %-42s" "$f"
  $PSQL_SUPER -v ON_ERROR_STOP=1 -q -d "$DB" -f "$f" >/dev/null && echo "ok"
done

echo "→ RLS + business logic tests"
$PSQL_SUPER -d "$DB" -f tests/rls_test.sql 2>&1 \
  | grep -E "PASS|FAIL|====" | sed 's/.*NOTICE:  //' | tee /tmp/habba_test_out.txt

fails=$(grep -c "FAIL" /tmp/habba_test_out.txt || true)
passes=$(grep -c "PASS" /tmp/habba_test_out.txt || true)
echo
echo "──────────────────────────────────────────"
echo "  $passes passed · $fails failed"
[ "$fails" -eq 0 ] || exit 1
