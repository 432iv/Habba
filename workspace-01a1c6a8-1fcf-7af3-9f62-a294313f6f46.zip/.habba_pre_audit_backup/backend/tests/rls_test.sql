-- ============================================================================
-- HABBA — RLS & business-logic test suite
--
-- Run against a database where migrations 0001..0006 have been applied:
--   psql -d habba_test -f tests/rls_test.sql
--
-- Every assertion prints PASS/FAIL. The suite impersonates anon and the owner
-- exactly the way PostgREST does (SET ROLE + request.jwt.claims).
-- ============================================================================

\set QUIET on
\pset pager off

-- ---------------------------------------------------------------------------
-- harness
-- ---------------------------------------------------------------------------
create or replace function pg_temp.assert(p_ok boolean, p_label text)
returns void language plpgsql as $$
begin
  if p_ok then
    raise notice 'PASS  %', p_label;
  else
    raise notice 'FAIL  %', p_label;
  end if;
end;
$$;

-- pretend to be the owner (auth.uid() reads request.jwt.claims)
create or replace function pg_temp.login_as(p_uid uuid)
returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', p_uid)::text, false);
end;
$$;

create or replace function pg_temp.setup_owner() returns uuid
language plpgsql as $$
declare v uuid := gen_random_uuid();
begin
  insert into auth.users (id) values (v);
  insert into public.profiles (id, full_name, role) values (v, 'Test Owner', 'owner');
  return v;
end;
$$;

-- anon session
create or replace function pg_temp.as_anon() returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', '{}', false);
end;
$$;

\echo ''
\echo '================ A. STOREFRONT (anon) ================'

set role anon;
select pg_temp.as_anon();

select pg_temp.assert(
  (select count(*) from public.products) = 9,
  'anon sees the 9 visible seeded products');

select pg_temp.assert(
  (select count(*) from public.catalog_feed() where is_new_arrival) =
  (select count(*) from public.products where is_visible and created_at >= now() - interval '3 days'),
  'new arrivals = products created within the last 3 days');

select pg_temp.assert(
  (select count(*) from public.catalog_feed() where discount_price is not null) = 1,
  'discounted feed contains exactly the discounted product');

-- privilege check first (does not abort the session), then a real write test
set role anon;
select pg_temp.assert(
  not has_table_privilege('anon', 'public.products', 'UPDATE'),
  'anon has no UPDATE privilege on products');
reset role;

-- hiding a product must remove it from the storefront
update public.products set is_visible = false where slug = 'musc-blanc';

set role anon;
select pg_temp.assert(
  (select count(*) from public.products) = 8,
  'hidden product disappears from anon catalogue');

select pg_temp.assert(
  not exists (select 1 from public.catalog_feed() where slug = 'musc-blanc'),
  'hidden product excluded from catalog_feed()');

reset role;
update public.products set is_visible = true where slug = 'musc-blanc';

-- brand visibility cascades to products
update public.brands set is_visible = false where slug = 'ibraq';
set role anon;
select pg_temp.assert(
  (select count(*) from public.products where brand_id = (select id from public.brands where slug='ibraq')) = 0,
  'hiding a brand hides all of its products from anon');
reset role;
update public.brands set is_visible = true where slug = 'ibraq';

-- anon must never read orders
set role anon;
select pg_temp.assert(
  (select count(*) from public.orders) = 0,
  'anon cannot read the orders table');

select pg_temp.assert(
  (select count(*) from public.order_items) = 0,
  'anon cannot read order items');

select pg_temp.assert(
  (select count(*) from public.profiles) = 0,
  'anon cannot read profiles');

-- anon cannot write catalogue data
select pg_temp.assert(
  not has_table_privilege('anon', 'public.products', 'INSERT'),
  'anon has no INSERT privilege on products');
reset role;

\echo ''
\echo '================ B. PLACING ORDERS ================'

-- orders are disabled by default: the function must refuse
set role anon;
do $$
begin
  perform public.place_order(
    jsonb_build_array(jsonb_build_object(
      'product_id', (select id from public.products where slug = 'soie-dor'),
      'quantity', 2)),
    'سارة أحمد', '0912345678', 'delivery', 'طرابلس - حي الأندلس', null);
  perform pg_temp.assert(false, 'place_order refuses while orders are disabled');
exception when others then
  perform pg_temp.assert(sqlerrm like '%ORDERS_DISABLED%', 'place_order refuses while orders are disabled');
end $$;
reset role;

-- owner enables ordering and sets the fee/threshold
update public.store_settings
   set orders_enabled = true, delivery_fee = 15, free_delivery_threshold = 400,
       whatsapp_number = '218910000000';

\echo '  (order placement with delivery + discount + free threshold)'
set role anon;
select r.order_id, r.order_number, r.subtotal, r.delivery_fee, r.total
from public.place_order(
  jsonb_build_array(
    jsonb_build_object('product_id', (select id from public.products where slug = 'soie-dor'), 'quantity', 2)
  ),
  'سارة أحمد', '0912345678', 'delivery', 'طرابلس - حي الأندلس، شارع الجامعة', 'توصيل بعد الخامسة'
) r;

select pg_temp.assert(
  (select subtotal from public.orders order by created_at desc limit 1) = 530,
  'subtotal uses the DISCOUNTED price (265 x 2 = 530, not 620)');

select pg_temp.assert(
  (select delivery_fee from public.orders order by created_at desc limit 1) = 15,
  'delivery fee applied from store settings');

select pg_temp.assert(
  (select total from public.orders order by created_at desc limit 1) = 545,
  'total = subtotal + delivery fee');

select pg_temp.assert(
  (select unit_price from public.order_items order by created_at desc limit 1) = 265
  and (select list_price from public.order_items order by created_at desc limit 1) = 310,
  'order item snapshots unit price AND the original list price');

select pg_temp.assert(
  (select order_number from public.orders order by created_at desc limit 1) ~ '^HB-[0-9]{6}-[0-9]{4}$',
  'order number follows HB-YYMMDD-NNNN');

-- pickup: no address stored, no fee
select r.order_id, r.order_number, r.subtotal, r.delivery_fee, r.total
from public.place_order(
  jsonb_build_array(jsonb_build_object('product_id', (select id from public.products where slug = 'rose-eternelle'), 'quantity', 1)),
  'منى علي', '0921111111', 'pickup', 'ignored address', null) r;

select pg_temp.assert(
  (select delivery_fee from public.orders order by created_at desc limit 1) = 0
  and (select delivery_address from public.orders order by created_at desc limit 1) is null,
  'pickup order has no fee and no address');

-- free delivery threshold
select r.order_id, r.order_number, r.subtotal, r.delivery_fee, r.total
from public.place_order(
  jsonb_build_array(jsonb_build_object('product_id', (select id from public.products where slug = 'noir-oud'), 'quantity', 2)),
  'هدى محمد', '0922222222', 'delivery', 'بنغازي - شارع دبي', null) r;

select pg_temp.assert(
  (select delivery_fee from public.orders order by created_at desc limit 1) = 0
  and (select subtotal from public.orders order by created_at desc limit 1) = 690,
  'free delivery applied above the configured threshold');

-- validation failures
do $$
begin
  perform public.place_order(
    jsonb_build_array(jsonb_build_object('product_id', (select id from public.products where slug = 'noir-oud'), 'quantity', 1)),
    'سارة أحمد', '123', 'delivery', 'طرابلس - حي الأندلس', null);
  perform pg_temp.assert(false, 'invalid phone rejected');
exception when others then
  perform pg_temp.assert(sqlerrm like '%INVALID_PHONE%', 'invalid phone rejected');
end $$;

do $$
begin
  perform public.place_order(
    jsonb_build_array(jsonb_build_object('product_id', (select id from public.products where slug = 'noir-oud'), 'quantity', 1)),
    'سارة أحمد', '0912345678', 'delivery', null, null);
  perform pg_temp.assert(false, 'delivery without address rejected');
exception when others then
  perform pg_temp.assert(sqlerrm like '%ADDRESS_REQUIRED%', 'delivery without address rejected');
end $$;

do $$
begin
  perform public.place_order('[]'::jsonb, 'سارة أحمد', '0912345678', 'pickup', null, null);
  perform pg_temp.assert(false, 'empty cart rejected');
exception when others then
  perform pg_temp.assert(sqlerrm like '%EMPTY_CART%', 'empty cart rejected');
end $$;

-- anon still cannot read the orders it just created
select pg_temp.assert(
  (select count(*) from public.orders) = 0,
  'customer cannot read any order back (no order history API)');
reset role;

\echo ''
\echo '================ C. HISTORICAL PRESERVATION ================'

-- delete the product that was ordered
delete from public.products where slug = 'soie-dor';

select pg_temp.assert(
  exists (select 1 from public.order_items where product_slug = 'soie-dor' and product_id is null),
  'deleting a product keeps its order lines (product_id set to NULL)');

select pg_temp.assert(
  (select count(*) from public.order_items where product_name_ar = 'سوا دور' and unit_price = 265) >= 1,
  'order lines keep the original name and price after product deletion');

\echo ''
\echo '================ D. ORDER STATUS WORKFLOW ================'

select pg_temp.setup_owner() as owner_id \gset
select pg_temp.login_as(:'owner_id');

set role authenticated;

select pg_temp.assert(
  (select count(*) from public.orders
    where customer_phone in ('0912345678','0921111111','0922222222')) = 3,
  'owner can read every order placed in section B (3 orders)');

select pg_temp.assert(
  (select count(*) from public.order_items) = 3,
  'owner can read order items (3 lines: qty 2 + 1 + 2)');

-- valid transition
update public.orders set status = 'confirmed' where status = 'new';
select pg_temp.assert(
  (select count(*) from public.orders where status = 'confirmed') >= 1,
  'owner moves an order new -> confirmed');

-- invalid jump
do $$
begin
  update public.orders set status = 'delivered' where id = (select id from public.orders where status = 'confirmed' limit 1);
  perform pg_temp.assert(false, 'illegal transition confirmed -> delivered blocked');
exception when others then
  perform pg_temp.assert(sqlerrm like '%invalid status transition%', 'illegal transition confirmed -> delivered blocked');
end $$;

-- financial data is immutable
do $$
begin
  update public.orders set total = 1 where id = (select id from public.orders where status = 'confirmed' limit 1);
  perform pg_temp.assert(false, 'order totals are immutable');
exception when others then
  perform pg_temp.assert(sqlerrm like '%immutable%', 'order totals are immutable');
end $$;

-- order items immutable: RLS denies the delete outright (0 rows affected)
create temp table _items_before as select count(*) as n from public.order_items;
delete from public.order_items where true;
select pg_temp.assert(
  (select count(*) from public.order_items) = (select n from _items_before),
  'order items cannot be deleted (0 rows removed)');

-- dashboard aggregation (section D moved every order out of 'new')
select pg_temp.assert(
  (public.admin_dashboard() -> 'stats' ->> 'awaiting_prep')::int = 3,
  'dashboard counts orders awaiting preparation');

select pg_temp.assert(
  (public.admin_dashboard() -> 'stats' ->> 'new_orders')::int = 0,
  'dashboard new-orders counter reflects the current statuses');

select pg_temp.assert(
  jsonb_array_length(public.admin_dashboard() -> 'best_sellers') >= 1,
  'dashboard returns best sellers from order history');

reset role;

\echo ''
\echo '================ E. OWNER-ONLY GUARANTEES ================'

-- a non-owner authenticated user (no profile) must be blocked
insert into auth.users (id) values ('11111111-1111-1111-1111-111111111111');
select pg_temp.login_as('11111111-1111-1111-1111-111111111111');
set role authenticated;

select pg_temp.assert(
  (select count(*) from public.products where not is_visible) = 0,
  'non-owner authenticated account sees only visible products');

do $$
begin
  insert into public.products (slug, name_ar, brand_id, category_id, size_label, price)
  values ('hack-attempt', 'اختراق', (select id from public.brands limit 1),
          (select id from public.categories limit 1), '100 مل', 10);
  perform pg_temp.assert(false, 'non-owner cannot insert products');
exception when insufficient_privilege or others then
  perform pg_temp.assert(true, 'non-owner cannot insert products');
end $$;

select pg_temp.assert(
  (select count(*) from public.orders) = 0,
  'non-owner cannot read orders');

select pg_temp.assert(
  public.is_owner() = false,
  'is_owner() is false for a non-owner account');

reset role;

-- second owner row is impossible
do $$
begin
  insert into public.profiles (id, role) values ('22222222-2222-2222-2222-222222222222', 'owner');
  perform pg_temp.assert(false, 'a second owner profile is rejected');
exception when unique_violation then
  perform pg_temp.assert(true, 'a second owner profile is rejected');
end $$;

\echo ''
\echo '================ F. SETTINGS & DERIVED SECTIONS ================'

select pg_temp.login_as(:'owner_id');
set role anon;
select pg_temp.assert(
  (public.public_settings() ->> 'whatsapp_number') = '218910000000',
  'storefront can read public settings (whatsapp)');
select pg_temp.assert(
  (public.public_settings() ->> 'orders_enabled')::boolean = true,
  'storefront sees the orders switch');
reset role;

select pg_temp.login_as(:'owner_id');
set role authenticated;
update public.store_settings set orders_enabled = false;
reset role;
select pg_temp.assert(
  (select orders_enabled from public.store_settings) = false,
  'owner can toggle order reception from settings');
select pg_temp.login_as('00000000-0000-0000-0000-000000000000');

-- new arrivals expiry: backdate a product beyond 3 days
select pg_temp.login_as(:'owner_id');
set role authenticated;
delete from public.products where slug = 'noir-oud';
reset role;
insert into public.products (slug, name_ar, brand_id, category_id, size_label, price, created_at)
values ('old-product', 'قديم', (select id from public.brands limit 1),
        (select id from public.categories limit 1), '100 مل', 100, now() - interval '4 days');

set role anon;
select pg_temp.assert(
  not exists (select 1 from public.catalog_feed() where slug = 'old-product' and is_new_arrival),
  'a product older than 3 days is NOT a new arrival');

select pg_temp.assert(
  exists (select 1 from public.catalog_feed() where slug = 'old-product'),
  'the same product is still listed in its normal category');
reset role;

-- discount section is derived from the column
update public.products set discount_price = 80 where slug = 'old-product';
set role anon;
select pg_temp.assert(
  exists (select 1 from public.catalog_feed() where slug = 'old-product' and discount_price is not null),
  'adding a discount automatically lists the product in discounts');
reset role;
update public.products set discount_price = null where slug = 'old-product';
set role anon;
select pg_temp.assert(
  not exists (select 1 from public.catalog_feed() where slug = 'old-product' and discount_price is not null),
  'removing the discount removes it from discounts');
reset role;

-- discount must be below price
do $$
begin
  update public.products set discount_price = 999 where slug = 'old-product';
  perform pg_temp.assert(false, 'discount above original price rejected');
exception when check_violation then
  perform pg_temp.assert(true, 'discount above original price rejected');
end $$;

\echo ''
\echo '================ G. UNIQUENESS / CONSTRAINTS ================'

do $$
begin
  insert into public.products (slug, name_ar, brand_id, category_id, size_label, price)
  values ('old-product', 'مكرر', (select id from public.brands limit 1),
          (select id from public.categories limit 1), '100 مل', 100);
  perform pg_temp.assert(false, 'duplicate slug rejected');
exception when unique_violation then
  perform pg_temp.assert(true, 'duplicate slug rejected');
end $$;

do $$
begin
  insert into public.orders (customer_name, customer_phone, fulfillment_method, subtotal, delivery_fee, total)
  values ('x', '0912345678', 'delivery', 100, 15, 115);
  perform pg_temp.assert(false, 'delivery order without address rejected by constraint');
exception when check_violation then
  perform pg_temp.assert(true, 'delivery order without address rejected by constraint');
end $$;

do $$
begin
  insert into public.orders (customer_name, customer_phone, fulfillment_method, subtotal, delivery_fee, total)
  values ('مريم سعيد', '0912345678', 'pickup', 100, 0, 90);
  perform pg_temp.assert(false, 'order whose total does not add up is rejected');
exception when check_violation then
  perform pg_temp.assert(true, 'order whose total does not add up is rejected');
end $$;

\echo ''
\echo '================ H. STOREFRONT INTEGRITY ================'
set role anon;
select pg_temp.assert(
  (select count(*) from public.catalog_feed() where image_path is null) =
  (select count(*) from public.catalog_feed()),
  'products without uploaded images are still listed (image handled by UI fallback)');
reset role;

select pg_temp.assert(
  has_function_privilege('anon', 'public.place_order(jsonb,text,text,public.fulfillment_method,text,text)', 'EXECUTE'),
  'anon may execute place_order (the only write path)');

select pg_temp.assert(
  not has_table_privilege('anon', 'public.orders', 'SELECT'),
  'anon has no direct SELECT on orders');

\echo ''
\echo '================ done ================'
